package com.software.program.astrixsa.system.app.productmanager;

public interface ProductI {
    String getName();
    String getDescripcion();
    Integer getImage();
}
