package com.software.program.astrixsa.system.app.productmanager;

public enum stateVideo {
    EN_LINEA, DESCARGADO
}
