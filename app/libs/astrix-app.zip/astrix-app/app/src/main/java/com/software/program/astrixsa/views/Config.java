package com.software.program.astrixsa.views;

public class Config {
    public static final String EMAIL ="ola.cid.astrix@gmail.com";
    public static final String PASSWORD ="8tsH.E19";
}